names = []
values = []

def get(name: str):
    try:
        for i in range(len(names)):
            if names[i] == name:
                return values[i]
        raise ValueError(f"Name '{name}' not found.")
    except Exception as e:
        raise TypeError(f"Error running 'get'. Error in code: {e}")

def var(name: str, value):
    try:
        if len(str(name)) >= 3 and len(str(value)) >= 3:
            for i in range(len(names)):
                if names[i] == name:
                    values[i] = value
                    return  # Update only
            # Add new entry
            names.append(name)
            values.append(value)
    except Exception as e:
        raise TypeError(f"Error running 'var'. Error in code: {e}")

def remove(name: str):
    try:
        for i in range(len(names)):
            if names[i] == name:
                del names[i]
                del values[i]
                return
        raise ValueError(f"Name '{name}' not found.")
    except Exception as e:
        raise TypeError(f"Error running 'remove'. Error in code: {e}")
