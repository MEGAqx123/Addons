def Or(bool):
    return(any(bool))

def And(bool):
    return(all(bool))

def Nor(bool):
    return(not any(bool))

def Nand(bool):
    return(not all(bool))

def Xor(bool):
    return(any(bool) and not all(bool))

def same(a,b):
    if a == b:
        return(True)
    return(False)