class CustomList:
    def __init__(self, initial_list=None):
        if initial_list is None:
            initial_list = []
        self.data = initial_list

    def insert(self, place:int, value):
        # Insert the value at the specified position
        if place >= len(self.data):
            self.data.append(value)
        else:
            self.data = self.data[:place] + [value] + self.data[place:]

    def remove_index(self, index:int):
        # Remove the element at the given index
        if 0 <= index < len(self.data):
            del self.data[index]

    def appstart(self, value):
        # Insert value at the start of the list
        self.insert(0, value)

    def __repr__(self):
        return str(self.data)
